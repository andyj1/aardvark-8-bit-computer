compile.c is a C program to simiulate a linker, performing multiple functions:

1. translating psuedo code to instructions in core ISA
2. translates global data to binary code
3. Prepare for linking and convert labels to numbers

compile2.c converts linker file to binary file

test.bin, test.cpp: sample test file to test the readmemb functionality of verilog

multiplication.txt, multiplication_linker.txt, multiplication.bin : sample multiplication

summation.txt, summation_linker.txt, summation.bin : sample summation
